%Note- the filter function is same as lin conv except it truncates the no.
%of samples to max(len(y), len(coeffs))
[music16k, fs1] = audioread('music16khz.wav');
[speech8k, fs2] = audioread('speech8khz.wav');

fvtool(music16k)
title("Magnitude spectrum of input music16k signal")

fvtool(speech8k)
title("Magnitude spectrum of input speech8k signal")
%% a) Downsample by 2 
music16k_ds = downsample(music16k,2);
speech8k_ds = downsample(speech8k,2);
'Playing sound 1 and then sound 2'
%playblocking(audioplayer(music16k_ds, fs1/2));
%playblocking(audioplayer(speech8k_ds, fs2/2));
audiowrite("music16k_ds_2.wav",music16k_ds,fs1/2);
audiowrite("speech8k_ds_2.wav",speech8k_ds,fs2/2);

fvtool(music16k_ds)
title("Magnitude spectrum of input music16k signal after downsampling by 2")

fvtool(speech8k_ds)
title("Magnitude spectrum of input speech8k signal after downsampling by 2")

%% b) Designing AA equiripple LP filter before DS by 2.
%Equiripple filter
%Specs:
%lowpass fir
%wp = 0.45pi is 0.45pi*fs/(2pi) in CT 
%ws = 0.55pi is 0.55pi*fs/(2pi) in CT
%Stopband attenuation: 100dB (good quality)

%AA filtering
AA1 = designfilt('lowpassfir', 'StopbandAttenuation',100, 'PassbandFrequency',(0.45), 'StopbandFrequency', (0.55), 'DesignMethod','Equiripple');
fvtool(AA1)
title("Equiripple LPF ~ pi/2"); 
music16k_filtered = filter( AA1, music16k);
speech8k_filtered = filter( AA1, speech8k);

%Downsampling
music16k_DS_AA = downsample(music16k_filtered,2);
speech8k_DS_AA = downsample(speech8k_filtered,2);

'Replaying'
%pause(2)
%playblocking(audioplayer(music16k_DS_AA, fs1/2));
%playblocking(audioplayer(speech8k_DS_AA, fs2/2));

fvtool(music16k_DS_AA)
title("Magnitude spectrum of input music16k signal after AA and downsampling by 2")

fvtool(speech8k_DS_AA)
title("Magnitude spectrum of input speech8k signal after AA and downsampling by 2")

audiowrite("music16k_AA_0.5pi_ds_2.wav",music16k_DS_AA,fs1/2);
audiowrite("speech8k_AA_0.5pi_ds_2.wav",speech8k_DS_AA,fs2/2);
%% c) Designing an equiripple filter LPF of given specs
%Equiripple filter
%Specs:
%lowpass fir
%wp = 0.22pi is 0.22pi*fs/(2pi) in CT 
%ws = 0.28pi is 0.28pi*fs/(2pi) in CT
%Stopband attenuation: 100dB (good quality)

Eqrpl_LPF = designfilt('lowpassfir', 'StopbandAttenuation',100,  'PassbandFrequency',(0.22), 'StopbandFrequency', (0.28) , 'DesignMethod', 'Equiripple');

fvtool(Eqrpl_LPF);
title("Equiripple LPF ~ pi/4");
%% d) Upsampling by 3 then passing to AA filter (pi/4) + DS by 4 unit.

%Upsampling by 3
music16k_us = upsample(music16k,3);
speech8k_us = upsample(speech8k,3);

fvtool(music16k_us)
title("Magnitude spectrum of input music16k signal after upsampling by 3")

fvtool(speech8k_us)
title("Magnitude spectrum of input speech8k signal after upsampling by 3")

%Applying LPF(~pi/4) designed earlier
music16k_filt_us = filter( Eqrpl_LPF , music16k_us );
speech8k_filt_us = filter( Eqrpl_LPF , speech8k_us );

%Downsampling by 4
music16k_ds_filt_us = downsample(music16k_filt_us,4);
speech8k_ds_filt_us = downsample(speech8k_filt_us,4);

'Upsampling by 3 then passing to AA filter (pi/4) + DS by 4 unit and Replaying'
%pause(2)
%playblocking(audioplayer(music16k_ds_filt_us, 3*fs1/4));
%playblocking(audioplayer(speech8k_ds_filt_us, 3*fs2/4));

fvtool(music16k_ds_filt_us)
title("Magnitude spectrum of input music16k signal after upsampling by 3, passing to AA filter then DS by 4")

fvtool(speech8k_ds_filt_us)
title("Magnitude spectrum of input speech8k signal after upsampling by 3, passing to AA filter then DS by 4")

audiowrite("music16k_us_3_AA_0.25pi_ds_4.wav",music16k_ds_filt_us,3*fs1/4);
audiowrite("speech8k_us_3_AA_0.25pi_ds_4.wav",speech8k_ds_filt_us,3*fs2/4);

%% e)
%Filtering using lowpass equiripple AA filter designed earlier
music16k_filt_Eqrpl_LPF = filter(Eqrpl_LPF, music16k);
speech8k_filt_Eqrpl_LPF = filter(Eqrpl_LPF, speech8k);

%Downsampling by 4
music16k_filt_Eqrpl_LPF_ds = downsample(music16k_filt_Eqrpl_LPF, 4);
speech8k_filt_Eqrpl_LPF_ds = downsample(speech8k_filt_Eqrpl_LPF, 4);

%Upsample by 3
music16k_filt_Eqrpl_LPF_ds_us = upsample(music16k_filt_Eqrpl_LPF_ds, 3);
speech8k_filt_Eqrpl_LPF_ds_us = upsample(speech8k_filt_Eqrpl_LPF_ds, 3);

%Mag spec for the signal after AA filtering , DS-4, US-3

fvtool(music16k_filt_Eqrpl_LPF_ds_us)
title("Magnitude spectrum of input music16k signal after AA filtering, DS by 4 and US by 3")

fvtool(speech8k_filt_Eqrpl_LPF_ds_us)
title("Magnitude spectrum of input speech8k signal after AA filtering, DS by 4 and US by 3")

%Creating an interpolation filter of given support [-8,8] - 17 samples
%L param 3, alpha is 1 for full nyquist bandwidth
%total samples 17 = 2*l*p - 1
%So, p = 3
l = 3;
p = 3;
alpha = 1;

interp_filt  = intfilt(l,p,alpha);
interp_den_coeffs= [1];
fvtool(interp_filt)
%Here shift doesnt matter its magnitude rsp anyway
title("Magnitue Response of interpolation filter");

[h,t] = impz(interp_filt,interp_den_coeffs);
t2 = t-8
stem(t2,h);
title("Impulse Response of interpolation filter supposrt [-8,8]")

%In order to capture the effect of support [-8,8], we assume h is of
%support [0,16] first, now if we advance h, o/p y will advance by 8
%samples. So, the filter output is just advanced by 8 samples( or basically
%ignore first 8)

%music16k_zero_pad = vertcat(zeros(8,1),music16k_filt_Eqrpl_LPF_ds_us);
%speech8k_zero_pad = vertcat(zeros(8,1),speech8k_filt_Eqrpl_LPF_ds_us);

%Interpolation or filtering- otherwise lin conv with coeffs.
music16k_interp = conv(interp_filt,music16k_filt_Eqrpl_LPF_ds_us);
speech8k_interp = conv(interp_filt,speech8k_filt_Eqrpl_LPF_ds_us);

%Trimming end samples just like the filter function to maintain total
%sample number
%music16k_interp = music16k_interp(1:max(length(interp_filt),length(music16k_zero_pad)));
%speech8k_interp = speech8k_interp(1:max(length(interp_filt),length(speech8k_zero_pad)));

%Ignoring first 8 samples of output as prev. discussed and maintaining
%equal samples at input and output of filter - just like the "filter"
%method
music16k_interp = music16k_interp(9:max( length(interp_filt),length(music16k_filt_Eqrpl_LPF_ds_us) ) + 8 );
speech8k_interp = speech8k_interp(9:max( length(interp_filt),length(speech8k_filt_Eqrpl_LPF_ds_us) ) + 8 );

fvtool(music16k_interp)
title("Magnitude spectrum of input music16k signal after AA filtering, DS by 4, US by 3 then interpolation")

fvtool(speech8k_interp)
title("Magnitude spectrum of input speech8k signal after AA filtering, DS by 4 and US by 3 then interpolation")

'Playing interpolated signals'
%pause(2)
%playblocking(audioplayer(music16k_interp, 3*fs1/4));
%playblocking(audioplayer(speech8k_interp, 3*fs2/4));

audiowrite("music16k_AA_0.25pi_ds_4_us_3_interp.wav",music16k_interp,3*fs1/4);
audiowrite("speech8k_AA_0.25pi_ds_4_us_3_interp.wav",speech8k_interp,3*fs2/4);

