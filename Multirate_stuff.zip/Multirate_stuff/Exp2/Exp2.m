%% Main Code

%Note- the filter function is same as lin conv except it truncates the no.
%of samples to max(len(y), len(coeffs))
[music16k, fs1] = audioread('music16khz.wav');
[speech8k, fs2] = audioread('speech8khz.wav');

%Freq. scale
freq_1 = transpose(linspace(0,2*pi, length(music16k)+1));
freq_1 = freq_1(1:end-1);
music16k_fft = fft(music16k);
figure;
plot(freq_1,abs(music16k_fft));
plt_func("music16k input")

%Freq. scale2
freq_2 = transpose(linspace(0,2*pi, length(speech8k)+1));
freq_2 = freq_2(1:end-1);
speech8k_fft = fft(speech8k);
figure;
plot(freq_2,abs(speech8k_fft));
plt_func("speech8k input")

%Analysis filter H_0 used:
H_0 = designfilt('lowpassfir', 'StopbandAttenuation',40, 'PassbandFrequency',(0.45), 'StopbandFrequency', (0.55), 'DesignMethod','Equiripple');
%Even indexed coeffs go to H0_0
H_0_coeffs=transpose(H_0.Coefficients);
%Impulse resp.
n=linspace(0,length(H_0_coeffs)-1,length(H_0_coeffs));
figure;
stem(n,H_0_coeffs)
grid on
xlabel("index ->")
ylabel("h0(n) - >")
title("Impulse Response of H0(z) equiripple Type 2 Analysis filter used") 
H_0_0 = H_0_coeffs(1:2:end);

%Odd indexed coeffs go to H0_1
H_0_1 = H_0_coeffs(2:2:end);

%Plot of Tzp(w) and H0(jw):
%Taking a 1024 pt fft
H_0_fft = fft(H_0_coeffs,1024);

%Freq axis
freq_1 = transpose(linspace(0,2*pi, length(H_0_fft)+1));
freq_1 = freq_1(1:end-1);
figure;
subplot(2,1,1)
plot(freq_1,abs(H_0_fft))
title("Magnitude Resp.of Analysis filter- H0(z)")
xlabel("w (norm. angular freq-radians) ->")
ylabel("Abs. value of 1024 pt. FFT H0(jw)  (Linear Scale) ->")
grid on
subplot(2,1,2)
plot(freq_1,unwrap(angle(H_0_fft)))
title("Phase Resp. of Analysis Filter- H0(z)")
xlabel("w (norm. angular freq-radians) ->")
ylabel("Phase of 1024 pt. FFT H0(jw) (radians)->")
grid on
%N = length(H_0_coeffs) - 1
%Hzp is e^(+jwN/2)*H_0(jw)

%Note- N is (length(H_0_coeffs)-1) always
H_0_zp = (H_0_fft).*exp(+j*freq_1*(length(H_0_coeffs)-1)/2)
H_0_zp_shifted = circshift(H_0_zp,length(H_0_fft)/2);
Tzp = 0.5*(abs(H_0_zp).^2 + abs(H_0_zp_shifted).^2);

figure;
%Plotting for 0,pi. Note- 1024pt fft
plot(freq_1(1:512), Tzp(1:512) );
%plot(freq_1, Tzp );

grid on;
title("Plot of Tzp(w) (Using 1024 pt FFT)- the z.p. part of net transfer function (Case 1)")
xlabel("w (norm. angular freq-radians) ->");
ylabel("Tzp(w) (Linear scale)- > ");

%Sending input to Analysis+synth fb structure
%Note- assumption is first sample is x(-1) (non zero)
%First speech8k signal
[vd_0_speech, vd_1_speech] = dft_analys_fb(speech8k);
%Defining synth filters:
%Case 1:
K_0 = H_0_1;
K_1 = H_0_0;

y_speech_case1 = dft_synth_fb(vd_0_speech, vd_1_speech, K_0,K_1);
%Freq. scale
freq_1 = transpose(linspace(0,2*pi, length(y_speech_case1)+1));
freq_1 = freq_1(1:end-1);
y_speech_case1_fft = fft(y_speech_case1);
figure;
plot(freq_1,abs(y_speech_case1_fft));
plt_func("Output signal (y) (case 1) for input speech")
audiowrite("speech8k_output_case1.wav",y_speech_case1,fs2);

%Case 2:
K_0 = H_0_0;
K_1 = H_0_1;
y_speech_case2 = dft_synth_fb(vd_0_speech, vd_1_speech, K_0,K_1);

%Freq. scale
freq_2 = transpose(linspace(0,2*pi, length(y_speech_case2)+1));
freq_2 = freq_2(1:end-1);
y_speech_case2_fft = fft(y_speech_case2);
figure;
plot(freq_2,abs(y_speech_case2_fft));
plt_func("Output signal (y) (case 2) for input speech")
audiowrite("speech8k_output_case2.wav",y_speech_case2,fs2);


%For the Music16k signal
[vd_0_music, vd_1_music] = dft_analys_fb(music16k);
%Defining synth filters:
%Case 1:
K_0 = H_0_1;
K_1 = H_0_0;

y_music_case1 = dft_synth_fb(vd_0_music, vd_1_music, K_0,K_1);
%Freq. scale
freq_1 = transpose(linspace(0,2*pi, length(y_music_case1)+1));
freq_1 = freq_1(1:end-1);
y_music_case1_fft = fft(y_music_case1);
figure;
plot(freq_1,abs(y_music_case1_fft));
plt_func("Output signal (y) (case 1) for input music")
audiowrite("music16k_output_case1.wav",y_music_case1,fs1);

%Case 2:
K_0 = H_0_0;
K_1 = H_0_1;
y_music_case2 = dft_synth_fb(vd_0_music, vd_1_music, K_0,K_1);

%Freq. scale
freq_2 = transpose(linspace(0,2*pi, length(y_music_case2)+1));
freq_2 = freq_2(1:end-1);
y_music_case2_fft = fft(y_music_case2);
figure;
plot(freq_2,abs(y_music_case2_fft));
plt_func("Output signal (y) (case 2) for input music")
audiowrite("music16k_output_case2.wav",y_music_case2,fs1);

%% Plot function
function plt_func(name)
grid on;
title("FFT of "+name+" signal")
xlabel("w (norm. angular freq-radians) ->");
ylabel("Abs. value of FFT (Linear scale)- > ");
end
%% Analysis FB
function [vd_0,vd_1]=dft_analys_fb(x)
%Note- Assume x is of the form { x(-1), x(0), ....}

%Delay x by 1 sample ( x is already in that form)
s = x; 

%Now, x is made to start from x(0)
x = x(2:end);
%Now its of form{ x(0),x(1)....}

%Downsample stage
x_d = downsample(x,2);
s_d = downsample(s,2);

H_0 = designfilt('lowpassfir', 'StopbandAttenuation',40, 'PassbandFrequency',(0.45), 'StopbandFrequency', (0.55), 'DesignMethod','Equiripple');
%Even indexed coeffs go to H0_0
'coeffs'
H_0_coeffs=transpose(H_0.Coefficients)
H_0_0 = H_0_coeffs(1:2:end);
%Odd indexed coeffs go to H0_1
H_0_1 = H_0_coeffs(2:2:end);

t_0 = conv(H_0_0,x_d);
t_1 = conv(H_0_1,s_d);

t_0 = t_0(1:length(x_d));
t_1 = t_1(1:length(s_d));

vd_0 = t_0+t_1;
vd_1 = t_0-t_1;

end

%% Synthesis FB
function y = dft_synth_fb(vd_0,vd_1,K0,K1)
%The "?" mark box - W matrix gives out u_0, u_1
u_0 = vd_0+vd_1;
u_1 = vd_0-vd_1;

%Filters K0(output - y_1(.))  and K1(output- y_0(.)) filter coeffs are given in as arguments
y_1 = conv(K0, u_0);
y_0 = conv(K1, u_1);

%Trimming
y_1 = y_1(1:length(u_0));
y_0 = y_0(1:length(u_1));

%Finding y(.)
y_1_us = upsample(y_1,2);
y_0_us = upsample(y_0,2);
y_1_us_shift = transpose([0, transpose(y_1_us)]);
%0 padding end of y_0_us for add
y_0_us_padd= transpose([ transpose(y_0_us), 0]);
y = y_0_us_padd+ y_1_us_shift;

end

